DATA={
"title" : "Configure your network",
"smalltitle" : "Network",
"description" : 'Configuring your wired or wireless connection in Xbian is really easy. Xbian can run without internet access but you will have a better experience with it.',
"action" : ['categories.10_system.NetworkSetting']
}
