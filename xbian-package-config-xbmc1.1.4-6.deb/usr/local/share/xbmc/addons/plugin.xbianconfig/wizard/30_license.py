DATA={
"title" : "Enter your License key",
"smalltitle" : "License key",
"description" : 'The Raspberry Pi can decode the majority of video and audio formats, however, in order to decode VC-1 (Used in some BluRay discs) and MPEG-2, you will need to purchase a license key for these.[CR]They are available at http://www.raspberrypi.com/license-keys/[CR][CR]If you already have a license key, you can enter it now.',
"action" : ['categories.10_system.vc1License','categories.10_system.mpeg2License']
}
