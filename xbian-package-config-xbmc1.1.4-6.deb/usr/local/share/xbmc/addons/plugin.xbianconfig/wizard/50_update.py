DATA={
"title" : "Update XBian",
"smalltitle" : "update",
"description" : 'You can now choose how Xbian will be updated and how often to check for updates.[CR][CR]By default, Xbian will not be updated automatically, but you will be advised when a new update is available.[CR][CR]To update :Go System -> Xbian -> Update and select the packages to upgrade.[CR][CR]If you wish Xbian to be updated automatically, you can set it now.',
"action" : ['categories.40_update.UpdateLabel','categories.40_update.InventoryIntGui','categories.40_update.updateAuto','categories.40_update.snapAPT','categories.40_update.updatePackageLabel','categories.40_update.packageUpdate']
}
