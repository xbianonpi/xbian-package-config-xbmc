DATA={
"title" : "Welcome to XBian",
"smalltitle" : "Welcome",
"description" : 'Thanks for choosing Xbian.[CR][CR]Xbian is a free Open Source media centre distribution for the Raspberry Pi.[CR]Our slogans is "XBMC on Raspberry Pi, the Bleeding edge" as our main focus is on delivering the fasted media centre for the Raspberry Pi.[CR][CR]We believe that everyone can make Xbian better.[CR]Please visit our Website www.forum.xbian.org for support or if you have any questions, suggestions or contributions, please share them with us!',
"action" : None
}
