DATA={
"title" : "It's time to play",
"smalltitle" : "Finish",
"description" : 'You now have a fully configured Xbian.[CR]We hope it will give you a great experience.[CR][CR]If you want to manage additional Xbian settings: Go System -> Xbian.[CR]If you want to rerun this Wizard at a later date: Select tab "Xbian Wizard" under System',
"action" : None
}
